package com.edu;

public class DoWhileMain {

	public static void main(String[] args) {
		int i=5;
		do {
			System.out.println("hello"); //sure even though condition is false 
			                             //statement will execute atlst once
		}while(i<4); 

		
		while(i<4) {
			System.out.println("hi");
		}
	}

}
