package com.edu;

public class NestedForLoop {

	public static void main(String[] args) {
		
		for(int r=1;r<=4;r++){
			  //for loop for blank
			 for(int b=1;b<=4-r;b++)
			 {
				 System.out.print(" ");
			 }
			   for(int c=1;c<=r;c++){
			     System.out.print("* ");
			}
			System.out.println();
			}
		}

}

